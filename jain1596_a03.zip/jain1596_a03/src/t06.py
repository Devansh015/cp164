"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-26"
-------------------------------------------------------
"""
from functions import reroute

print(reroute("SSXSSXXX", [1, 2, 3, 4]))