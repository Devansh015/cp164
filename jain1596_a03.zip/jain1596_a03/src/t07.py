"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-26"
-------------------------------------------------------
"""
from functions import is_mirror_stack

string = "abcmcba"
valid_chars = "abc"

m = "m"

value = is_mirror_stack(string, valid_chars, m)

print(value)