"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-26"
-------------------------------------------------------
"""
from functions import postfix
def main():
    string = "4 5.2 + "
    answer = postfix(string)
    print(answer)
main()