"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-07-14"
-------------------------------------------------------
"""
from BST_linked import BST

bst = BST()

bst.insert(11)
bst.insert(7)
bst.insert(4)
bst.insert(6)
bst.insert(10)
bst.insert(20)
bst.insert(4)
bst.insert(0)

yes = 7
no = 3

print(bst.node_counts())

print(yes in bst)
print(no in bst)

print(bst.parent(yes))
print(bst.parent_r(yes))