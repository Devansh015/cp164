"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-07-14"
-------------------------------------------------------
"""
from Hash_Set_BST import Hash_Set
from functions import insert_words, comparison_total

fn = "miserables.txt"

fv = open(fn, "r", encoding="utf-8")
hs = Hash_Set(20)

insert_words(fv, hs)
total, max_word = comparison_total(hs)

print("Using link BST based Hash Set")
print()
print("Total Comparisons: {:,}".format(total))
print("Word with maximum comparisons '{}': {:,}".format(
    max_word.word, max_word.comparisons))