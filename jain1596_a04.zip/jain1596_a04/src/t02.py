"""
-------------------------------------------------------
Task 2 
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-06-02"
-------------------------------------------------------
"""

from Queue_array import Queue

q1 = Queue()
q2 = Queue()

array = [1, 2, 3, 4, 5]

for i in array:
    q1.insert(i)
    q2.insert(i)

yes = q1 == q2
print(f"equal {yes}")