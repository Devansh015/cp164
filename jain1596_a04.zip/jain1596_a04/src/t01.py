"""
-------------------------------------------------------
Task 1 - Circular
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-06-02"
-------------------------------------------------------
"""
from Queue_circular import Queue

pq = Queue()

pq.insert(5)
pq.insert(10)
pq.insert(15)

pq.remove()
print(pq.peek())
full = pq.is_full()
empty = pq.is_empty()
print(f"full: {full}")
print(f"empty: {empty}")