"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-11"
-------------------------------------------------------
"""
from Movie import Movie

print(Movie.genres_menu())