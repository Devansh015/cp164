"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-12"
-------------------------------------------------------
"""
from functions import matrix_flatten

input_matrix = [['a', 'b'], ['x', 'z'], ['e', 'f']]
flattened_matrix = matrix_flatten(input_matrix)
print(flattened_matrix)
