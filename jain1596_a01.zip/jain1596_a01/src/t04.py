"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-12"
-------------------------------------------------------
"""
from functions import matrix_transpose

input_matrix = [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
transposed_matrix = matrix_transpose(input_matrix)
print(transposed_matrix)