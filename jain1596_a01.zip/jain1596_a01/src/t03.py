"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-12"
-------------------------------------------------------
"""
from functions import is_palindrome

test_string = "Able was I ere I saw Elba!"
is_palindrome_result = is_palindrome(test_string)
print(is_palindrome_result)