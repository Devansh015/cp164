"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-12"
-------------------------------------------------------
"""
from functions import matrixes_multiply

matrix_a = [[1, 2, 3], [4, 5, 6]]
matrix_b = [[7, 8], [9, 10], [11, 12]]
result_matrix = matrixes_multiply(matrix_a, matrix_b)
print(result_matrix)
