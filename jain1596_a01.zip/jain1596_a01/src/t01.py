"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-05-12"
-------------------------------------------------------
"""
from functions import list_subtraction

list = [5, 5, 4, 5]
subtrahend = [5]

list_subtraction(list, subtrahend)

print(list)