"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-07-21"
-------------------------------------------------------
"""
from Sorts_array import Sorts

a = [55, 45, 2, 405, 321, 9, 5, 67, 4]

Sorts.gnome_sort(a)

print(a)