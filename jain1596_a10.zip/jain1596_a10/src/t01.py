"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author: Devansh Jain    
ID:        169061596
Email:   jain1596@mylaurier.ca
__updated__ = "2024-07-21"
-------------------------------------------------------
"""
from Sorts_array import Sorts

a = [55, 45, 3, 289, 213, 1, 288, 53, 2, 9999]

Sorts.radix_sort(a)

print(a)